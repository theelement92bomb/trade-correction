<template>
  <div class="foreignTradeNew">
    <h1>New Foreign Trade</h1>
  </div>
</template>
