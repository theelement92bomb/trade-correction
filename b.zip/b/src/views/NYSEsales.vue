<template>
  <div class="NYSEsales">
    <h1>NYSE Short Sales</h1>
  </div>
</template>
