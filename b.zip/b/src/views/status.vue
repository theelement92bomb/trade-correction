<template>
  <div class="status">
    <h1>Activity Status</h1>
  </div>
</template>
