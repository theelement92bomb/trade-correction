<template>
  <div class="accessControl">
    <h1>Access Control</h1>
  </div>
</template>
