<template>
  <div class="userActivity">
    <h1>User Activity</h1>
  </div>
</template>
