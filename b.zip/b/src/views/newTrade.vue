<template>
  <div class="newTrade">
    <h1>New Trades</h1>
  </div>
</template>
